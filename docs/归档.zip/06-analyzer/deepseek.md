# 06-LLM ｜ DeepSeek 接入要点

> 模块：06 LLM 研判层 ｜ 成分：模型接入 ｜ 对应代码：analyzer/llm.py ｜ 实施阶段：P6
> 来源：原方案 §9.1

- `ChatOpenAI(openai_api_base=settings.deepseek_base_url, model=settings.deepseek_model)`。
- **结构化输出必须 `with_structured_output(method="function_calling")`**：DeepSeek 不支持 `response_format: json_schema`，默认 method 会 422；function_calling 走工具调用协议稳定可用。
- 模型名默认 `deepseek-v4-flash`（旧别名 `deepseek-chat` 仍可用），`.env` 可改；temperature 0.3。
- 成本：单次分析约 12k in + 2k out tokens，约 ¥0.02；即使每日一次月成本 <¥1。控成本三手段：不引 embedding、事件抽取与情绪打标批量单次调用、同日重复分析直接返回快照。
- 降级：DeepSeek 不可用/422 时分数照常产出、judge 降级为按分档直接给倾向并标注"LLM 降级"（协议见 [10-module-contracts.md §10.5](../10-module-contracts.md)）。
